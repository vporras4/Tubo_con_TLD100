/*
 * TDM_Analysis.hh
 *
 *  Created on: Nov 7, 2017
 *      Author: eduardo
 */

#ifndef INCLUDE_TDM_ANALYSIS_HH_
#define INCLUDE_TDM_ANALYSIS_HH_

#include "g4root.hh"

#endif /* INCLUDE_TDM_ANALYSIS_HH_ */
